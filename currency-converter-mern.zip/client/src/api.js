import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api"
});

export const getCurrencies = () => api.get("/currencies");
export const convert = (data) => api.post("/convert", data);
export const getLatest = (base) => api.get(`/rates/latest?base=${base}`);
export const getHistory = (base, target) =>
  api.get(`/rates/history?base=${base}&target=${target}&days=30`);
export const getFavorites = () => api.get("/favorites");
export const addFavorite = (data) => api.post("/favorites", data);
export const deleteFavorite = (id) => api.delete(`/favorites/${id}`);
export const budgetCompare = (data) => api.post("/budget/compare", data);
export const getConversionHistory = () => api.get("/history");
export const saveConversion = (data) => api.post("/history", data);
