import { useEffect, useMemo, useState } from "react";
import { ArrowDownUp, ChevronDown, Clock3, Heart, Plane, RefreshCw, Star, TrendingUp, X } from "lucide-react";
import {
  addFavorite, budgetCompare, convert, deleteFavorite, getCurrencies,
  getFavorites, getHistory, getConversionHistory, saveConversion
} from "./api";

const symbols = {
  USD: "$", EUR: "€", GBP: "£", INR: "₹", JPY: "¥", AUD: "A$",
  CAD: "C$", CHF: "CHF", CNY: "¥", SGD: "S$", NZD: "NZ$",
  AED: "د.إ", KRW: "₩", BRL: "R$", ZAR: "R"
};

function CurrencySelect({ value, onChange, currencies }) {
  return (
    <div className="select-wrap">
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {currencies.map((c) => (
          <option key={c.code} value={c.code}>{c.code} — {c.name}</option>
        ))}
      </select>
      <ChevronDown size={18} />
    </div>
  );
}

function App() {
  const [currencies, setCurrencies] = useState([]);
  const [base, setBase] = useState("USD");
  const [target, setTarget] = useState("INR");
  const [amount, setAmount] = useState("100");
  const [result, setResult] = useState(null);
  const [trend, setTrend] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [history, setHistory] = useState([]);
  const [budgetMode, setBudgetMode] = useState(false);
  const [budget, setBudget] = useState(null);
  const [loading, setLoading] = useState(false);
  const [trendLoading, setTrendLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([getCurrencies(), getFavorites(), getConversionHistory()])
      .then(([c, f, h]) => {
        setCurrencies(c.data);
        setFavorites(f.data);
        setHistory(h.data);
      })
      .catch((e) => setError(e.response?.data?.message || e.message));
  }, []);

  useEffect(() => {
    loadTrend();
  }, [base, target]);

  async function loadTrend() {
    if (base === target) return setTrend([]);
    setTrendLoading(true);
    try {
      const { data } = await getHistory(base, target);
      setTrend(data.points || []);
    } catch (e) {
      setTrend([]);
      setError(e.response?.data?.message || "Historical data could not be loaded.");
    } finally {
      setTrendLoading(false);
    }
  }

  async function handleConvert(e) {
    e?.preventDefault();
    setError("");
    if (base === target) {
      setResult({ amount: Number(amount), rate: 1, convertedAmount: Number(amount) });
      return;
    }
    setLoading(true);
    try {
      const { data } = await convert({ base, target, amount: Number(amount) });
      setResult(data);
      await saveConversion({
        base, target, amount: Number(amount),
        rate: data.rate, convertedAmount: data.convertedAmount
      });
      const h = await getConversionHistory();
      setHistory(h.data);
    } catch (e) {
      setError(e.response?.data?.message || e.message);
    } finally {
      setLoading(false);
    }
  }

  function swap() {
    setBase(target);
    setTarget(base);
    setResult(null);
  }

  async function toggleFavorite() {
    try {
      const existing = favorites.find(f => f.base === base && f.target === target);
      if (existing) {
        await deleteFavorite(existing._id);
        setFavorites(favorites.filter(f => f._id !== existing._id));
      } else {
        const { data } = await addFavorite({ base, target });
        setFavorites([data, ...favorites]);
      }
    } catch (e) {
      setError(e.response?.data?.message || e.message);
    }
  }

  async function useFavorite(f) {
    setBase(f.base);
    setTarget(f.target);
    setBudgetMode(false);
  }

  async function calculateBudget() {
    setError("");
    setLoading(true);
    try {
      const { data } = await budgetCompare({ base, amount: Number(amount) });
      setBudget(data);
    } catch (e) {
      setError(e.response?.data?.message || e.message);
    } finally {
      setLoading(false);
    }
  }

  const isFavorite = useMemo(
    () => favorites.some(f => f.base === base && f.target === target),
    [favorites, base, target]
  );

  const currentRate = result?.rate ?? (trend.length ? trend[trend.length - 1].rate : null);

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand"><div className="brand-icon">↗</div><div><b>CurrencyFlow</b><span>Global money, simplified.</span></div></div>
        <div className="top-actions">
          <button className={`travel-toggle ${budgetMode ? "active" : ""}`} onClick={() => { setBudgetMode(!budgetMode); setBudget(null); }}>
            <Plane size={17}/> Travel Budgeting
          </button>
        </div>
      </header>

      <main className="container">
        <section className="hero">
          <div>
            <div className="eyebrow">LIVE CURRENCY INTELLIGENCE</div>
            <h1>Convert with confidence.</h1>
            <p>Real-time exchange rates, 30-day trends, and smart travel budgeting in one place.</p>
          </div>
          <div className="live-pill"><span></span> Live rates</div>
        </section>

        {error && <div className="error">{error}<button onClick={() => setError("")}><X size={15}/></button></div>}

        <section className="converter-card">
          <div className="section-head">
            <div><h2>{budgetMode ? "Travel Budget" : "Currency Converter"}</h2><p>{budgetMode ? "See your budget across major currencies." : "Convert using the latest available market rate."}</p></div>
            <button className="icon-btn" title="Refresh" onClick={() => { loadTrend(); handleConvert(); }}><RefreshCw size={17}/></button>
          </div>

          <form onSubmit={handleConvert}>
            <div className="conversion-row">
              <div className="currency-box">
                <label>YOU SEND</label>
                <CurrencySelect value={base} onChange={setBase} currencies={currencies}/>
                <div className="amount-row"><span>{symbols[base] || base}</span><input value={amount} onChange={e => setAmount(e.target.value)} type="number" min="0" step="any"/></div>
              </div>

              <button type="button" className="swap-btn" onClick={swap}><ArrowDownUp size={20}/></button>

              <div className="currency-box">
                <label>YOU RECEIVE</label>
                <CurrencySelect value={target} onChange={setTarget} currencies={currencies}/>
                <div className="receive-amount">
                  <span>{symbols[target] || target}</span>
                  <strong>{result ? Number(result.convertedAmount).toLocaleString(undefined,{maximumFractionDigits:4}) : "—"}</strong>
                </div>
              </div>
            </div>

            <div className="action-row">
              <button className="primary-btn" disabled={loading}>{loading ? "Updating..." : budgetMode ? "Compare Budget" : "Convert Now"} <ArrowDownUp size={17}/></button>
              {!budgetMode && <button type="button" className={`favorite-btn ${isFavorite ? "selected" : ""}`} onClick={toggleFavorite}>{isFavorite ? <Star fill="currentColor" size={17}/> : <Heart size={17}/>} {isFavorite ? "Saved" : "Save Pair"}</button>}
            </div>
          </form>

          {budgetMode && (
            <div className="budget-results">
              <div className="budget-title"><div><h3>Travel comparison</h3><p>{amount} {base} converted to major currencies</p></div><Plane size={25}/></div>
              {budget ? (
                <div className="budget-grid">
                  {budget.comparison.map(row => (
                    <div className="budget-item" key={row.currency}>
                      <span>{row.currency}</span>
                      <strong>{symbols[row.currency]} {Number(row.value).toLocaleString(undefined,{maximumFractionDigits:2})}</strong>
                      <small>1 {base} = {row.rate.toFixed(4)} {row.currency}</small>
                    </div>
                  ))}
                </div>
              ) : <div className="empty-budget">Enter an amount and click Compare Budget.</div>}
            </div>
          )}
        </section>

        <div className="dashboard-grid">
          <section className="panel chart-panel">
            <div className="section-head">
              <div><div className="panel-label"><TrendingUp size={15}/> 30-DAY TREND</div><h2>{base} / {target}</h2></div>
              {currentRate && <div className="rate-badge">1 {base} = {currentRate.toFixed(4)} {target}</div>}
            </div>
            <div className="chart">
              {trendLoading ? <div className="chart-empty">Loading historical rates...</div> :
               trend.length === 0 ? <div className="chart-empty">No historical data available for this API plan.</div> :
               <SimpleChart data={trend}/>}
            </div>
          </section>

          <section className="panel">
            <div className="section-head"><div><div className="panel-label"><Star size={15}/> QUICK ACCESS</div><h2>Favorite pairs</h2></div></div>
            <div className="favorites-list">
              {favorites.length === 0 && <div className="muted">No saved pairs yet.</div>}
              {favorites.map(f => (
                <button className="favorite-row" key={f._id} onClick={() => useFavorite(f)}>
                  <div className="pair-icon">{f.base.slice(0,1)}<span>{f.target.slice(0,1)}</span></div>
                  <div><b>{f.base} / {f.target}</b><small>Tap to convert</small></div>
                  <ArrowDownUp size={15}/>
                </button>
              ))}
            </div>
          </section>
        </div>

        <section className="panel history-panel">
          <div className="section-head"><div><div className="panel-label"><Clock3 size={15}/> RECENT ACTIVITY</div><h2>Conversion history</h2></div></div>
          {history.length === 0 ? <div className="muted">Your recent conversions will appear here.</div> :
            <div className="history-list">{history.slice(0,8).map(h => (
              <div className="history-row" key={h._id}>
                <span>{h.base} → {h.target}</span><b>{h.amount} {h.base} = {Number(h.convertedAmount).toLocaleString(undefined,{maximumFractionDigits:2})} {h.target}</b>
                <small>{new Date(h.createdAt).toLocaleString()}</small>
              </div>
            ))}</div>}
        </section>

        <footer>CurrencyFlow • Rates provided by ExchangeRate-API • Built with MERN</footer>
      </main>
    </div>
  );
}

function SimpleChart({ data }) {
  const width = 800, height = 260, pad = 30;
  const values = data.map(d => d.rate);
  const min = Math.min(...values), max = Math.max(...values);
  const range = max - min || 1;
  const points = data.map((d,i) => {
    const x = pad + (i/(data.length-1 || 1))*(width-pad*2);
    const y = height-pad - ((d.rate-min)/range)*(height-pad*2);
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="trend-svg" preserveAspectRatio="none">
      {[0,1,2,3].map(i => <line key={i} x1={pad} x2={width-pad} y1={40+i*60} y2={40+i*60} stroke="currentColor" opacity=".08"/>)}
      <polyline fill="none" stroke="currentColor" strokeWidth="3" points={points}/>
      <text x={pad} y={height-5}>{data[0]?.date}</text>
      <text x={width-pad} y={height-5} textAnchor="end">{data[data.length-1]?.date}</text>
    </svg>
  );
}

export default App;
