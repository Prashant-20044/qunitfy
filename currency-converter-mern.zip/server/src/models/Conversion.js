import mongoose from "mongoose";

const conversionSchema = new mongoose.Schema(
  {
    base: { type: String, required: true, uppercase: true },
    target: { type: String, required: true, uppercase: true },
    amount: { type: Number, required: true },
    rate: { type: Number, required: true },
    convertedAmount: { type: Number, required: true }
  },
  { timestamps: true }
);

export default mongoose.model("Conversion", conversionSchema);
