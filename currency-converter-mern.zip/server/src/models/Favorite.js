import mongoose from "mongoose";

const favoriteSchema = new mongoose.Schema(
  {
    base: { type: String, required: true, uppercase: true },
    target: { type: String, required: true, uppercase: true }
  },
  { timestamps: true }
);

favoriteSchema.index({ base: 1, target: 1 }, { unique: true });

export default mongoose.model("Favorite", favoriteSchema);
