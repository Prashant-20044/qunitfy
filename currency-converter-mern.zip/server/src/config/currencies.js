export const currencies = [
  ["USD", "US Dollar", "$"],
  ["EUR", "Euro", "€"],
  ["GBP", "British Pound", "£"],
  ["INR", "Indian Rupee", "₹"],
  ["JPY", "Japanese Yen", "¥"],
  ["AUD", "Australian Dollar", "A$"],
  ["CAD", "Canadian Dollar", "C$"],
  ["CHF", "Swiss Franc", "CHF"],
  ["CNY", "Chinese Yuan", "¥"],
  ["SGD", "Singapore Dollar", "S$"],
  ["NZD", "New Zealand Dollar", "NZ$"],
  ["AED", "UAE Dirham", "د.إ"],
  ["KRW", "South Korean Won", "₩"],
  ["BRL", "Brazilian Real", "R$"],
  ["ZAR", "South African Rand", "R"]
].map(([code, name, symbol]) => ({ code, name, symbol }));

export const majorCurrencies = ["USD", "EUR", "GBP", "INR", "JPY"];
