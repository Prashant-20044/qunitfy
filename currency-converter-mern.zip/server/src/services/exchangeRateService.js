import axios from "axios";

const baseUrl = "https://v6.exchangerate-api.com/v6";

const getKey = () => {
  if (!process.env.EXCHANGE_RATE_API_KEY) {
    throw new Error("EXCHANGE_RATE_API_KEY is not configured");
  }
  return process.env.EXCHANGE_RATE_API_KEY;
};

export async function getLatestRates(base) {
  const url = `${baseUrl}/${getKey()}/latest/${base}`;
  const { data } = await axios.get(url, { timeout: 10000 });

  if (data.result !== "success") {
    throw new Error(data["error-type"] || "ExchangeRate API request failed");
  }

  return {
    base: data.base_code,
    rates: data.conversion_rates,
    updatedAt: data.time_last_update_utc
  };
}

export async function getPairRate(base, target) {
  const data = await getLatestRates(base);
  const rate = data.rates[target];

  if (!rate) throw new Error(`Unsupported currency: ${target}`);
  return rate;
}

/*
 * ExchangeRate-API's historical/time-series availability depends on the
 * subscription plan. This adapter first tries the timeseries endpoint.
 * If the plan does not expose it, the frontend receives a clear error
 * instead of silently displaying fake historical values.
 */
export async function getHistoricalRates(base, target, days = 30) {
  const key = getKey();
  const end = new Date();
  const start = new Date(end);
  start.setDate(start.getDate() - (Number(days) - 1));

  const fmt = (d) => d.toISOString().slice(0, 10);
  const url = `${baseUrl}/${key}/timeseries/${base}/${fmt(start)}/${fmt(end)}`;

  const { data } = await axios.get(url, { timeout: 15000 });

  if (data.result !== "success") {
    throw new Error(
      data["error-type"] ||
      "Historical data is unavailable for the current ExchangeRate-API plan."
    );
  }

  const points = Object.entries(data.conversion_rates || {})
    .map(([date, rates]) => ({
      date,
      rate: Number(rates[target])
    }))
    .filter((p) => Number.isFinite(p.rate))
    .sort((a, b) => a.date.localeCompare(b.date));

  return { base, target, points };
}
