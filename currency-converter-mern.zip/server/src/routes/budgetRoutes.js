import { Router } from "express";
import { majorCurrencies } from "../config/currencies.js";
import { getLatestRates } from "../services/exchangeRateService.js";

const router = Router();

router.post("/compare", async (req, res) => {
  try {
    const base = String(req.body.base || "USD").toUpperCase();
    const amount = Number(req.body.amount);

    if (!Number.isFinite(amount) || amount < 0) {
      return res.status(400).json({ message: "Amount must be a valid non-negative number." });
    }

    const data = await getLatestRates(base);

    const comparison = majorCurrencies
      .filter((code) => code !== base)
      .map((currency) => ({
        currency,
        rate: data.rates[currency],
        value: amount * data.rates[currency]
      }))
      .filter((row) => Number.isFinite(row.rate));

    res.json({ base, amount, comparison, updatedAt: data.updatedAt });
  } catch (error) {
    res.status(502).json({ message: error.message });
  }
});

export default router;
