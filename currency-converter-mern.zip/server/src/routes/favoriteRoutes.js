import { Router } from "express";
import Favorite from "../models/Favorite.js";

const router = Router();

router.get("/", async (_, res) => {
  res.json(await Favorite.find().sort({ createdAt: -1 }));
});

router.post("/", async (req, res) => {
  try {
    const base = String(req.body.base || "").toUpperCase();
    const target = String(req.body.target || "").toUpperCase();

    if (!base || !target || base === target) {
      return res.status(400).json({ message: "Invalid currency pair." });
    }

    const favorite = await Favorite.findOneAndUpdate(
      { base, target },
      { base, target },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    res.status(201).json(favorite);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    await Favorite.findByIdAndDelete(req.params.id);
    res.json({ message: "Favorite removed." });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
