import { Router } from "express";
import Conversion from "../models/Conversion.js";

const router = Router();

router.get("/", async (_, res) => {
  const items = await Conversion.find().sort({ createdAt: -1 }).limit(20);
  res.json(items);
});

router.post("/", async (req, res) => {
  try {
    const item = await Conversion.create(req.body);
    res.status(201).json(item);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

export default router;
