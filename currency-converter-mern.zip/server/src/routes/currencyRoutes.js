import { Router } from "express";
import { currencies } from "../config/currencies.js";
import { getLatestRates, getHistoricalRates } from "../services/exchangeRateService.js";

const router = Router();

router.get("/currencies", (_, res) => res.json(currencies));

router.get("/rates/latest", async (req, res) => {
  try {
    const base = String(req.query.base || "USD").toUpperCase();
    res.json(await getLatestRates(base));
  } catch (error) {
    res.status(502).json({ message: error.message });
  }
});

router.get("/rates/history", async (req, res) => {
  try {
    const base = String(req.query.base || "USD").toUpperCase();
    const target = String(req.query.target || "INR").toUpperCase();
    const days = Math.min(Math.max(Number(req.query.days || 30), 2), 90);
    res.json(await getHistoricalRates(base, target, days));
  } catch (error) {
    res.status(502).json({ message: error.message });
  }
});

router.post("/convert", async (req, res) => {
  try {
    const { base = "USD", target = "INR", amount } = req.body;
    const numericAmount = Number(amount);

    if (!Number.isFinite(numericAmount) || numericAmount < 0) {
      return res.status(400).json({ message: "Amount must be a valid non-negative number." });
    }

    const rates = await getLatestRates(String(base).toUpperCase());
    const targetCode = String(target).toUpperCase();
    const rate = rates.rates[targetCode];

    if (!rate) return res.status(400).json({ message: "Unsupported target currency." });

    res.json({
      base: rates.base,
      target: targetCode,
      amount: numericAmount,
      rate,
      convertedAmount: numericAmount * rate,
      updatedAt: rates.updatedAt
    });
  } catch (error) {
    res.status(502).json({ message: error.message });
  }
});

export default router;
