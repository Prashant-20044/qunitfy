# Currency Converter — MERN

A full-stack MERN currency converter with:
- Live exchange rates through ExchangeRate-API
- 30-day historical trend chart
- MongoDB-backed favorites and conversion history
- Travel Budgeting mode for 5 major currencies
- Currency swap and responsive UI

## Requirements
- Node.js 18+
- MongoDB (local or Atlas)
- ExchangeRate-API key: https://www.exchangerate-api.com/

## Setup

### 1. Backend
```bash
cd server
npm install
copy .env.example .env
```
Edit `.env`:
```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/currency_converter
EXCHANGE_RATE_API_KEY=your_key
CLIENT_URL=http://localhost:5173
```

Run:
```bash
npm run dev
```

### 2. Frontend
```bash
cd client
npm install
npm run dev
```

Open http://localhost:5173

## API
- GET `/api/currencies`
- GET `/api/rates/latest?base=USD`
- GET `/api/rates/history?base=USD&target=INR&days=30`
- POST `/api/convert`
- GET `/api/favorites`
- POST `/api/favorites`
- DELETE `/api/favorites/:id`
- GET `/api/history`
- POST `/api/budget/compare`
